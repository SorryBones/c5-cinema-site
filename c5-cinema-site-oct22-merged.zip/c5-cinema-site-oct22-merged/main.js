const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');
const encoder = bodyParser.urlencoded();
const app = express();

app.use(express.static('.'));

var loggedIn = false;

// connect to database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'NewCES',
});
connection.connect(function(error) {
    if (error) throw error
    else console.log("connected to database")
})

// LOGIN
app.post('/login', encoder, function(req,res) {
    let email = req.body.email;
    let password = req.body.password;

    connection.query('SELECT * FROM user WHERE email = ? AND password = ?',[email, password],function(error,results,fields){
        if (results.length > 0) {
            console.log('logged in');
            loggedIn = true;
            res.redirect('/index.html');
        } else {
            console.log('failed to log in');
            res.redirect('/login.html');
        }
        res.end();
    })
})

// REGISTER
app.post('/register', encoder, function(req,res) {
    let firstName = req.body.fname;
    let lastName = req.body.lname;
    let phone = req.body.phone;
    let email = req.body.email;
    let confirmEmail = req.body.confemail;
    let password = req.body.password;
    let confirmPassword = req.body.confpassword;

    // Optional
    // let cardType = req.body.cardtype;
    // let cardNumber = req.body.cardnumb;
    // let cardExpiration = req.body.expDate;

    // let billingStreet = req.body.billingStreet;
    // let billingCity = req.body.billingCity;
    // let billingState = req.body.billingState;
    // let billingZip = req.body.billingZip;

    // let homeStreet = req.body.homeStreet;
    // let homeCity = req.body.homeCity;
    // let homeState = req.body.homeState;
    // let homeZip = req.body.homeZip;

    if (email != confirmEmail) {
        console.log('emails are not same');
    }
    else if (password != confirmPassword) {
        console.log('passwords are not same');
    }
    else {
        connection.query('INSERT INTO user (first_name, last_name, phone_num, email, password, utype_id, status_id) VALUES (?, ?, ?, ?, ?, 1, 1);',[firstName, lastName, phone, email, password],function(error,results,fields){
            console.log('success');
            res.redirect('/registerConfirmation.html');
        })
    }
})


// GET
app.get('/profile',function(req,res) {
    if (loggedIn) res.redirect('/profile.html')
    else res.redirect('/login.html')
})
app.get('/logout',function(req,res) {
    console.log('logged out')
    loggedIn = false;
    res.redirect('/login.html');
})

app.listen(4000);