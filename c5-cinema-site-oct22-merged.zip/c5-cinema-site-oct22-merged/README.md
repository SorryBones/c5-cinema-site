# c5-cinema-site
Section C group 5:
    Alex Bone               adb45749
    Will Howell             wah48679
    Anjiya Kazani           afk01397
    Kofi Reeves-Miller      kmr99059
    Luke Palmer             lbp27389

Date: 09/28/22 x:xxPM

Assignment: Project deliverable 3